const express = require('express');
const router = express.Router();
const chatbotService = require('../services/chatbotService');

// Route to handle chatbot messages
router.post('/chat', async (req, res) => {
    const userMessage = req.body.message;
    try {
        const botResponse = await chatbotService.processMessage(userMessage);
        res.json({ response: botResponse });
    } catch (error) {
        res.status(500).json({ error: 'An error occurred while processing your message.' });
    }
});

module.exports = router;