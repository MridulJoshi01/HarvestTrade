const chatbotResponses = {
    "hello": "Hello! How can I assist you today?",
    "market price": "You can check the latest market prices for various crops on our website.",
    "weather": "I can provide you with the latest weather updates. Please enter your city.",
    "help": "You can ask me about market prices, weather updates, or general inquiries related to agriculture.",
    "default": "I'm sorry, I didn't understand that. Can you please rephrase?"
};

function processChatbotMessage(userInput) {
    const lowerCaseInput = userInput.toLowerCase();
    return chatbotResponses[lowerCaseInput] || chatbotResponses["default"];
}

module.exports = {
    processChatbotMessage
};