// This file contains the JavaScript code that handles user interactions with the chatbot. 
// It manages sending messages, receiving responses, and updating the chat window.

document.addEventListener("DOMContentLoaded", function() {
    const chatWindow = document.getElementById("chat-window");
    const inputField = document.getElementById("user-input");
    const sendButton = document.getElementById("send-button");

    sendButton.addEventListener("click", sendMessage);
    inputField.addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
            sendMessage();
        }
    });

    function sendMessage() {
        const userMessage = inputField.value.trim();
        if (userMessage) {
            appendMessage("You: " + userMessage);
            inputField.value = "";
            fetchResponse(userMessage);
        }
    }

    function appendMessage(message) {
        const messageElement = document.createElement("div");
        messageElement.textContent = message;
        chatWindow.appendChild(messageElement);
        chatWindow.scrollTop = chatWindow.scrollHeight; // Scroll to the bottom
    }

    async function fetchResponse(userMessage) {
        try {
            const response = await fetch("/api/chatbot", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({ message: userMessage })
            });

            const data = await response.json();
            if (data.reply) {
                appendMessage("Bot: " + data.reply);
            } else {
                appendMessage("Bot: Sorry, I didn't understand that.");
            }
        } catch (error) {
            appendMessage("Bot: Error connecting to the server.");
        }
    }
});