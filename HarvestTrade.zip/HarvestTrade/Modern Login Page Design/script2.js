document.getElementById("userInput").addEventListener("keypress", async function (e) {
    if (e.key === "Enter") {
      const input = this.value;
      const messagesDiv = document.getElementById("messages");
      messagesDiv.innerHTML += `<div><strong>You:</strong> ${input}</div>`;
      this.value = "";
  
      // Simulated response
      const reply = await fetch("https://api.example.com/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: input })
      }).then(res => res.json());
  
      messagesDiv.innerHTML += `<div><strong>Bot:</strong> ${reply.response}</div>`;
      messagesDiv.scrollTop = messagesDiv.scrollHeight;
    }
  });
  moonBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark-mode");
    moonBtn.src = document.body.classList.contains("dark-mode") ? "sun-icon.png" : "moon-icon.png";
  });
  document.getElementById("cityInput").focus();
