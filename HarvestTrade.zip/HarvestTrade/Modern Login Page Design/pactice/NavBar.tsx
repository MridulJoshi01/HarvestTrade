import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Search, ShoppingCart, Menu, X, User, Tag } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";

const NavBar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const isMobile = useIsMobile();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <span className="text-harvest-600 font-bold text-2xl">HarvestTrade</span>
          </Link>

          {/* Desktop Navigation */}
          {!isMobile && (
            <div className="flex items-center space-x-8">
              <Link to="/browse" className="text-gray-600 hover:text-harvest-600 transition-colors">
                Browse
              </Link>
              <Link to="/sell" className="text-gray-600 hover:text-harvest-600 transition-colors">
                Sell
              </Link>
              <Link to="/about" className="text-gray-600 hover:text-harvest-600 transition-colors">
                About Us
              </Link>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search crops..."
                  className="pl-10 pr-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-harvest-500 focus:border-transparent"
                />
                <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
              </div>
            </div>
          )}

          {/* Right Side Navigation */}
          <div className="flex items-center space-x-4">
            {!isMobile ? (
              <>
                <Link to="/sell">
                  <Button variant="harvest" className="flex items-center">
                    <Tag className="mr-2 h-5 w-5" />
                    List for Sale
                  </Button>
                </Link>
                <Link to="/login">
                  <Button variant="ghost" className="flex items-center">
                    <User className="mr-2 h-5 w-5" />
                    Login
                  </Button>
                </Link>
                <Link to="/cart">
                  <Button variant="ghost" className="relative">
                    <ShoppingCart className="h-5 w-5" />
                    <span className="absolute -top-1 -right-1 bg-harvest-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      0
                    </span>
                  </Button>
                </Link>
              </>
            ) : (
              <Button variant="ghost" onClick={toggleMenu}>
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            )}
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobile && isMenuOpen && (
          <div className="mt-4 pb-4 space-y-4 bg-white">
            <div className="relative mx-4">
              <input
                type="text"
                placeholder="Search crops..."
                className="w-full pl-10 pr-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-harvest-500 focus:border-transparent"
              />
              <Search className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" />
            </div>
            <div className="flex flex-col space-y-2">
              <Link
                to="/sell"
                className="px-4 py-2 mb-2 bg-harvest-500 text-white rounded-md hover:bg-harvest-600 transition-colors flex items-center justify-center"
                onClick={() => setIsMenuOpen(false)}
              >
                <Tag className="mr-2 h-5 w-5" /> List for Sale
              </Link>
              <Link
                to="/browse"
                className="px-4 py-2 text-gray-600 hover:bg-gray-100 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Browse
              </Link>
              <Link
                to="/sell"
                className="px-4 py-2 text-gray-600 hover:bg-gray-100 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Sell
              </Link>
              <Link
                to="/about"
                className="px-4 py-2 text-gray-600 hover:bg-gray-100 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                About Us
              </Link>
              <Link
                to="/login"
                className="px-4 py-2 text-gray-600 hover:bg-gray-100 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Login
              </Link>
              <Link
                to="/cart"
                className="px-4 py-2 text-gray-600 hover:bg-gray-100 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                Cart (0)
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default NavBar;
